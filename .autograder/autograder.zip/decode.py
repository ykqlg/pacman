#!/usr/bin/env python

"""
decode.py: Decodes submission tokens.

Can be used from the command-line to pretty-print submission tokens; see below
for usage.
"""

import binascii
import codecs
import json
import rsa
import sys

RSA_PRIVATE_KEY = (36786304852261144029274009415324198959L, 56285023496349038954935919614579038707L)


def decode(token_path):
    """Returns the data contained in the token file at the specified path. The
    returned object is a Python dict. Fails loudly (i.e., does not catch
    any exceptions)."""
    contents = binascii.a2b_base64(codecs.open(token_path, 'r', 'utf-8').read())
    decoded = rsa.decode(contents, RSA_PRIVATE_KEY)
    return json.loads(decoded)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'Usage: python decode.py [token_file]'
        sys.exit(1)
    data = decode(sys.argv[1])
    print json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))
