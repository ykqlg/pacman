#!/usr/bin/env python

"""
server.py: Decodes and verifies a submission token.

For documentation on the Gradescope autograder framework, see
http://gradescope-autograders.readthedocs.io/en/latest/.
"""

import imp
import json
import os.path
import sys

import decode
import rsa

# Settings
PROJECT = 'search'  # UPDATE: This specifies what project to expect
REQUIRED_FIELDS = ['project',
                   'local_time',
                   'gmt_time',
                   'duration_sec',
                   'score',
                   'raw_output',
                   'self_contents',
                   'current_dir',
                   'current_dir_ls',
                   'work_dir',
                   'work_dir_ls',
                   'work_dir_checksums',
                   'work_dir_student_files']

# These paths are defined by Gradescope
TOKEN = '/autograder/submission/%s.token' % PROJECT
RESULTS = '/autograder/results/results.json'


def write_results(score, output=''):
    """Writes to the results file."""
    with open(RESULTS, 'w') as f:
        f.write(json.dumps({'score': score, 'output': output}))


def fail(output):
    """Fails, writing the given error message to the results file."""
    write_results(0, output)
    sys.exit()


def get_token_data():
    """Attempts to open, decode, and parse the token file. Returns the token
    data as a dict if the token is readable; fails otherwise."""
    if not os.path.isfile(TOKEN):
        fail('Could not find your token. ' +
             'Please retry, but this time upload your token file. ' +
             'Your token file must be called %s.token.' % PROJECT)
    try:
        return decode.decode(TOKEN)
    except:
        fail('Could not understand your submission. ' +
             'Are you sure you uploaded a valid token file?')


def validate(token_data):
    """Performs basic checks to ensure token validity."""
    for field in REQUIRED_FIELDS:
        if field not in token_data:
            fail('Your token is incomplete. ' +
                 'Are you sure you uploaded a valid token file?')
    if (token_data['project'] != PROJECT or
       'Total: ' + token_data['score'] not in token_data['raw_output']):
        # Intentionally vague message to discourage gaming of autograder
        fail('Your token is not valid. ' +
             'Check that you uploaded the token for the correct project.')


def get_score_and_output(token_data):
    """Returns the final score and raw output from the token data."""
    score, max_score = map(float, token_data['score'].split('/'))
    return score, token_data['raw_output']


def main():
    """This is the main execution sequence."""
    try:
        token_data = get_token_data()
        validate(token_data)
        score, _ = get_score_and_output(token_data)
        write_results(score, 'Your score has been recorded. Thank you!')
    except Exception as e:
        fail('An uncaught exception occurred: %s' % str(e))

if __name__ == '__main__':
    main()
